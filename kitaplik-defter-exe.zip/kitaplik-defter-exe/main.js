const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
function createWindow() {
  Menu.setApplicationMenu(null);
  const win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 700, minHeight: 500,
    title: 'Kitaplık Defter', autoHideMenuBar: true,
    webPreferences: { webSecurity: false }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
