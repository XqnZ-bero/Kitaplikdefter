@echo off
chcp 65001 >nul
echo Kurulum basliyor (internet gerekli, 2-5 dakika surebilir)...
call npm install
if errorlevel 1 goto hata
call npx --yes @electron/packager . KitaplikDefter --platform=win32 --arch=x64 --out=dist --overwrite --ignore=dist
if errorlevel 1 goto hata
echo.
echo BITTI! Uygulama: dist\KitaplikDefter-win32-x64\KitaplikDefter.exe
explorer dist\KitaplikDefter-win32-x64
pause
exit /b
:hata
echo.
echo HATA oldu. Node.js kurulu mu? Bu ekrandaki yaziyi bana gonder.
pause
